  <script src="{{url('assets')}}/plugins/jquery/jquery.min.js"></script>
  <script src="{{url('assets')}}/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>