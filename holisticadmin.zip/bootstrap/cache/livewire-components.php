<?php return array (
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'login' => 'App\\Http\\Livewire\\Login',
  'user' => 'App\\Http\\Livewire\\User',
  'user.edit-user' => 'App\\Http\\Livewire\\User\\EditUser',
);